gcc -Wall -g -o x64_dis x64_dis.c

python asm_to_hex.py "imul cx, dx, 0x123" data1
python asm_to_hex.py "imul eax, ebx, 0x1234" data2
python asm_to_hex.py "imul eax, [ebx], 0x1234" data3
python asm_to_hex.py "imul rax, [rbx], 0x12345678" data4
python asm_to_hex.py "imul rax, rbx, 0x1234" data5
python asm_to_hex.py "imul eax, ebx, 0x1" data6
python asm_to_hex.py "imul eax, [ebx], 0x1" data7
python asm_to_hex.py "imul rax, [ebx], 0x1" data8
python asm_to_hex.py "imul rax, [rbx], 0xc" data9
python asm_to_hex.py "imul eax, [rbx], 0xda" data10
python asm_to_hex.py "imul ax, [ebx], 0xff" data11

echo ""
for i in $(seq 1 11); do
    ./x64_dis data$i
    echo ""
done