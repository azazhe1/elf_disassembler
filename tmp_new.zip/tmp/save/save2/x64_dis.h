#include <elf.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

#define CASSE_PIED -100

#define R8 0
#define R16 1
#define R32 2
#define R64 3
#define R16_32_64 2
#define R16_64 3
#define R32_64 2

#define R_M8 4
#define R_M16_32 6
#define R_M32 CASSE_PIED
#define R_M32_64 6
#define R_M64 7
#define R_M64_16 7
#define R_M16_32_64 6

#define IMM8 -1
#define IMM16 -2
#define IMM32 -3
#define IMM16_32 -3
#define IMM64 -4

//8-bit registers
#define AL 0
#define CL 1
#define DL 2
#define BL 3
#define AH 4
#define CH 5
#define DH 6
#define BH 7

//16-bit registers
#define AX 0
#define CX 1
#define DX 2
#define BX 3
#define SP 4
#define BP 5
#define SI 6
#define DI 7

//32-bit registers
#define EAX 0
#define ECX 1
#define EDX 2
#define EBX 3
#define ESP 4
#define EBP 5
#define ESI 6
#define EDI 7

//64-bit registers
#define RAX 0
#define RCX 1
#define RDX 2
#define RBX 3
#define RSP 4
#define RBP 5
#define RSI 6
#define RDI 7

typedef struct {
    Elf64_Addr addr;
    char *inst;
    uint8_t legacy_prefix;
    uint8_t inst_size;
    int REX[5];
    int op_order;
    int op1_type;
    int op2_type;
    int op1;
    int op2;
}Instruction_Decoded;


typedef struct {
    char*inst_name;
    int op1_type; //Type : r16, r32,... ,imm64
    int op2_type; //Type : r16, r32,... ,imm64
    int op1;
    int op2; // NULL in default but somme instruction need spécific register like 35 XOR	rAX	imm16/32
}Instruction;

const char *registers[4][8] = {
    {"al", "cl", "dl", "bl", "ah", "ch", "dh", "bh"},
    {"ax", "cx", "dx", "bx", "sp", "bp", "si", "di"},
    {"eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi"},
    {"rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi"}
};

const uint8_t LegacyPrefix[13] = {0xf0, 0xf2, 0xf3, 0x3e, 0x36, 0x3E, 0x26, 0x64, 0x65, 0x2e, 0x3e, 0x66, 0x67};

Instruction InstructionSet[256] = {0};

#define INST(i, name, r_type_2, r_type_1) \
    InstructionSet[i].inst_name = name; \
    InstructionSet[i].op2_type = r_type_2; \
    InstructionSet[i].op1_type = r_type_1; \
    InstructionSet[i].op2 = -1; \
    InstructionSet[i].op1 = -1

//Macro for special instruction
#define INST_S(i, name, r_type_2, r_type_1, r_2, r_1) \
    InstructionSet[i].inst_name = name; \
    InstructionSet[i].op2_type = r_type_2; \
    InstructionSet[i].op1_type = r_type_1; \
    InstructionSet[i].op2 = r_2; \
    InstructionSet[i].op1 = r_1

//Macro for instruction one operande
#define INST_1(i, name, r_type_2, r_2) \
    InstructionSet[i].inst_name = name; \
    InstructionSet[i].op2_type = r_type_2; \
    InstructionSet[i].op1_type = 0xff; \
    InstructionSet[i].op2 = r_2; \
    InstructionSet[i].op1 = -1
