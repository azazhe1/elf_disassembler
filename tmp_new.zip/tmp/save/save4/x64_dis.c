#include <stdio.h>
#include <stdlib.h>
#include "x64_dis.h"

void initialize_instructions(){
    //ADD
    INST_2(0x00, "add", R_M8, R8);
    INST_2(0x01, "add", R_M16_32_64, R16_32_64);
    INST_2(0x02, "add", R8, R_M8);
    INST_2(0x03, "add", R16_32_64, R_M16_32_64);
    INST_S(0x04, "add", R8, IMM8, AL, -1);
    INST_S(0x05, "add", R64, IMM16_32, RAX, -1);
    //OR
    INST_2(0x08, "or", R_M8, R8);
    INST_2(0x09, "or", R_M16_32_64, R16_32_64);
    INST_2(0x0a, "or", R8, R_M8);
    INST_2(0x0b, "or", R16_32_64, R_M16_32_64);
    INST_S(0x0c, "or", R8, IMM8, AL, -1);
    INST_S(0x0d, "or", R64, IMM16_32, RAX, -1);
    //ADC
    INST_2(0x10, "adc", R_M8, R8);
    INST_2(0x11, "adc", R_M16_32_64, R16_32_64);
    INST_2(0x12, "adc", R8, R_M8);
    INST_2(0x13, "adc", R16_32_64, R_M16_32_64);
    INST_S(0x14, "adc", R8, IMM8, AL, -1);
    INST_S(0x15, "adc", R64, IMM16_32, RAX, -1);
    //SBB
    INST_2(0x18, "sbb", R_M8, R8);
    INST_2(0x19, "sbb", R_M16_32_64, R16_32_64);
    INST_2(0x1a, "sbb", R8, R_M8);
    INST_2(0x1b, "sbb", R16_32_64, R_M16_32_64);
    INST_S(0x1c, "sbb", R8, IMM8, AL, -1);
    INST_S(0x1d, "sbb", R64, IMM16_32, RAX, -1);
    //AND
    INST_2(0x20, "and", R_M8, R8);
    INST_2(0x21, "and", R_M16_32_64, R16_32_64);
    INST_2(0x22, "and", R8, R_M8);
    INST_2(0x23, "and", R16_32_64, R_M16_32_64);
    INST_S(0x24, "and", R8, IMM8, AL, -1);
    INST_S(0x25, "and", R64, IMM16_32, RAX, -1);
    //SUB
    INST_2(0x28, "sub", R_M8, R8);
    INST_2(0x29, "sub", R_M16_32_64, R16_32_64);
    INST_2(0x2a, "sub", R8, R_M8);
    INST_2(0x2b, "sub", R16_32_64, R_M16_32_64);
    INST_S(0x2c, "sub", R8, IMM8, AL, -1);
    INST_S(0x2d, "sub", R64, IMM16_32, RAX, -1);
    //XOR
    INST_2(0x30, "xor", R_M8, R8);
    INST_2(0x31, "xor", R_M16_32_64, R16_32_64);
    INST_2(0x32, "xor", R8, R_M8);
    INST_2(0x33, "xor", R16_32_64, R_M16_32_64);
    INST_S(0x34, "xor", R8, IMM8, AL, -1);
    INST_S(0x35, "xor", R64, IMM16_32, RAX, -1);
    //CMP
    INST_2(0x38, "cmp", R_M8, R8);
    INST_2(0x39, "cmp", R_M16_32_64, R16_32_64);
    INST_2(0x3a, "cmp", R8, R_M8);
    INST_2(0x3b, "cmp", R16_32_64, R_M16_32_64);
    INST_S(0x3c, "cmp", R8, IMM8, AL, -1);
    INST_S(0x3d, "cmp", R64, IMM16_32, RAX, -1);
    //PUSH
    INST_1(0x50, "push", R16_64, RAX);
    INST_1(0x51, "push", R16_64, RCX);
    INST_1(0x52, "push", R16_64, RDX);
    INST_1(0x53, "push", R16_64, RBX);
    INST_1(0x54, "push", R16_64, RSP);
    INST_1(0x55, "push", R16_64, RBP);
    INST_1(0x56, "push", R16_64, RSI);
    INST_1(0x57, "push", R16_64, RDI);
    INST_1(0x68, "push", IMM16_32, -1);
    INST_1(0x6A, "push", IMM8, -1);
    //POP
    INST_1(0x58, "pop", R16_64, RAX);
    INST_1(0x59, "pop", R16_64, RCX);
    INST_1(0x5a, "pop", R16_64, RDX);
    INST_1(0x5b, "pop", R16_64, RBX);
    INST_1(0x5c, "pop", R16_64, RSP);
    INST_1(0x5d, "pop", R16_64, RBP);
    INST_1(0x5e, "pop", R16_64, RSI);
    INST_1(0x5f, "pop", R16_64, RDI);
    //MOVSXD
    INST_2(0x63, "movsxd", R32_64, R_M32);
    //IMUL
    INST_3(0x69, "imul", R16_32_64, R_M16_32_64, IMM16_32);
    INST_3(0x6b, "imul", R16_32_64, R_M16_32_64, IMM8);
}

uint8_t check_legacy_prefix(u_int8_t mem, Instruction_Decoded *inst_disass){
    uint8_t res = 0;

    for(int i = 0; i < 13; i++){
        if(mem == LegacyPrefix[i]){
            inst_disass->legacy_prefix = LegacyPrefix[i];
            res = 1;
            break;
        }
    }
    if(res == 0){
        inst_disass->legacy_prefix = 0x00;
    }
    inst_disass->inst_size+=res;
    return res;
}

uint8_t check_rex_prefix(uint8_t mem, Instruction_Decoded *inst_disass){
    uint8_t res = 0;

    if( mem >= 0x40 && mem <= 0x4f){
        inst_disass->REX[0] = 1;
        inst_disass->REX[1] = (mem >> 3) & 0x01; // W bit (bit 3)
        inst_disass->REX[2] = (mem >> 2) & 0x01; // R bit (bit 2)
        inst_disass->REX[3] = (mem >> 1) & 0x01; // X bit (bit 1)
        inst_disass->REX[4] = mem & 0x01;        // B bit (bit 0)
        res = 1;
        inst_disass->op2_type++;
        inst_disass->op1_type++;
    }else {
        inst_disass->REX[0] = 0;
        inst_disass->REX[1] = 0; // W bit (bit 3)
        inst_disass->REX[2] = 0; // R bit (bit 2)
        inst_disass->REX[3] = 0; // X bit (bit 1)
        inst_disass->REX[4] = 0; // B bit (bit 0)
    }
    inst_disass->inst_size+=res;
    return res;
}
uint8_t decode_opcode(uint8_t mem, Instruction_Decoded *inst_disass){
    uint8_t opcode_size = 0;
    Instruction instruction = InstructionSet[mem];

    if(instruction.inst_name != 0){
        inst_disass->inst = instruction.inst_name;
        opcode_size = 1;
        inst_disass->op1_type += instruction.op1_type;
        inst_disass->op2_type += instruction.op2_type;
        inst_disass->op3_type += instruction.op3_type;
        if(instruction.op2_type == R_M32) inst_disass->op2_type = 6;
        if(instruction.op1 !=-1){
            inst_disass->op1_type = instruction.op1_type;
            inst_disass->op2_type = instruction.op2_type;
            inst_disass->op1 = instruction.op1;
        }
        if(instruction.op2 !=-1){
            inst_disass->op1_type = instruction.op1_type;
            inst_disass->op2_type = instruction.op2_type;
            inst_disass->op2 = instruction.op2;
        }
        if(instruction.op3 != -1){
            inst_disass->op3_type = instruction.op3_type;
            inst_disass->op3 = instruction.op3;
        }
    }else{
        fprintf(stderr,"Invalid instruction %x\n", mem);
        exit(EXIT_FAILURE);
    }
    inst_disass->inst_size+=1;
    return opcode_size;
}

int get_imm(uint8_t *mem, int imm_type, int *r, uint8_t legacy_prefix){
    int res = 0;

    switch (imm_type)
    {
    case IMM8:  *r = *(uint8_t *)mem; res = 1; break;
    case IMM16: *r = *(uint16_t *)mem; res = 2; break;
    case IMM32: *r = *(uint32_t *)mem; res = 4; break;
    case IMM64: *r = *(uint64_t *)mem; res = 8; break;
    default:
        break;
    }
    if(legacy_prefix == 0x66){
        *r = *(uint16_t *)mem; res = 2;
    }
    return res;
}

void print_hex_inst(uint8_t *mem, uint8_t inst_size){
    for(uint8_t i =0; i < inst_size; i++){
        printf("%02x ", mem[i]);
    }
    printf("\n");
}

uint8_t decode_1_operande(uint8_t *mem, Instruction_Decoded *inst_disass, int default_size){
    uint8_t res= 0;
    int imm;

    if(inst_disass->op1_type >= 0){
        printf("%s %s", inst_disass->inst, registers[default_size][inst_disass->op1]);
    }else {
        res += get_imm(mem, inst_disass->op1_type, &imm, inst_disass->legacy_prefix);
        printf("%s 0x%x", inst_disass->inst, imm);
    }
    return res;
}

uint8_t decode_2_operande(uint8_t *mem, Instruction_Decoded *inst_disass, int default_size){
    uint8_t res= 0;
    uint8_t mod;
    int imm;
    int reg;
    int rm;
    if(inst_disass->op2 != -1){
        res += get_imm(mem, inst_disass->op1_type, &imm, inst_disass->legacy_prefix);
        printf("%s 0x%x, %s", inst_disass->inst, imm, registers[inst_disass->op2_type][inst_disass->op2]);
    }else if(inst_disass->op1 != -1){
        res += get_imm(mem, inst_disass->op2_type, &imm, inst_disass->legacy_prefix);
        printf("%s %s, 0x%x", inst_disass->inst, registers[inst_disass->op1_type][inst_disass->op1], imm);
    }else{
        mod = *mem >> 6;
        reg = (*mem >> 3) & 7;
        rm =  *mem & 7;
        mem++;
        res++;
        switch (mod)
        {
        case 0://Adresse indirecte sans déplacement
            if(inst_disass->op1_type > 3){
                printf("%s [%s], %s", inst_disass->inst, registers[default_size][rm], registers[inst_disass->op2_type][reg]);
            }else {
                printf("%s %s, [%s]", inst_disass->inst, registers[inst_disass->op1_type][reg], registers[default_size][rm]);
            }
            break;
        case 1://Adresse indirecte avec déplacement de 8 bits
            res += get_imm(mem, IMM8, &imm, inst_disass->legacy_prefix);
            if(inst_disass->op1_type > 3){
                printf("%s [%s+0x%x], %s", inst_disass->inst, registers[default_size][rm], imm, registers[inst_disass->op2_type][reg]);
            }else {
                printf("%s %s, [%s+0x%x]", inst_disass->inst, registers[inst_disass->op1_type][reg], registers[default_size][rm], imm);
            }
            break;
        case 2://Adresse indirecte avec déplacement de 32 bits
            res += get_imm(mem, IMM32, &imm, inst_disass->legacy_prefix);
            if(inst_disass->op1_type > 3){
                printf("%s [%s+0x%x], %s", inst_disass->inst, registers[default_size][rm], imm, registers[inst_disass->op2_type][reg]);
            }else {
                printf("titi");
                printf("%s %s, [%s+0x%x]", inst_disass->inst, registers[inst_disass->op1_type][reg], registers[default_size][rm], imm);
            }
            break;
        default:
            uint8_t avant = (mod<< 6 )+ (reg << 3) + rm;
            printf("*mem = %x default : reg = %d, rm = %d ", avant,reg, rm);
            if(inst_disass->op2_type >=0 && inst_disass->op1_type < 4){
                printf("%s %s, %s", inst_disass->inst, registers[inst_disass->op1_type - (0x66 == inst_disass->legacy_prefix)][rm], registers[inst_disass->op2_type - 4 -(0x66 == inst_disass->legacy_prefix)][reg]);
            }else if (inst_disass->op2_type >=0){
                printf("%s %s, %s", inst_disass->inst, registers[inst_disass->op1_type - 4 - (0x66 == inst_disass->legacy_prefix)][rm], registers[inst_disass->op2_type - (0x66 == inst_disass->legacy_prefix)][reg]);
            }else{
                printf("OP no supported");
            }
            break;
        }
    }
    return res;
}

uint8_t decode_3_operande(uint8_t *mem, Instruction_Decoded *inst_disass, int default_size){
    uint8_t res =0;
    int imm;

    res += decode_2_operande(mem, inst_disass, default_size);
    if(inst_disass->op3_type >= 0 && inst_disass->op3_type < 4){
        printf(", %s", registers[inst_disass->op3_type - (0x66 == inst_disass->legacy_prefix)][inst_disass->op3]);
    }else if(inst_disass->op3_type > 4){
        printf(", [%s]", registers[inst_disass->op3_type - 4 - (0x66 == inst_disass->legacy_prefix)][inst_disass->op3]);
    }else{
        res += get_imm(&mem[res], inst_disass->op3_type, &imm, inst_disass->legacy_prefix);
        printf(", 0x%x", imm);
    }
    return res;
}

uint8_t decode_operande(uint8_t *mem, Instruction_Decoded *inst_disass){
    uint8_t res = 0;
    int default_size = R64;

    if(inst_disass->legacy_prefix == 0x67) default_size = R32;
    if(inst_disass->legacy_prefix == 0x66) default_size = R16;
    if(inst_disass->op2 == OP_NULL) res += decode_1_operande(mem, inst_disass, default_size);
    else if(inst_disass->op3 == OP_NULL) res += decode_2_operande(mem, inst_disass, default_size);
    else res += decode_3_operande(mem, inst_disass, default_size);
    inst_disass->inst_size += res;
    printf("\n");
    return res;
}

int decodeInst(uint8_t *mem, Elf64_Addr addr, Instruction_Decoded *inst_disass){
    addr += check_legacy_prefix(mem[addr], inst_disass);
    addr += check_rex_prefix(mem[addr], inst_disass);
    //printf("REX[0] = %d\n", inst_disass->REX[0]); // W
    //printf("REX[1] = %d\n", inst_disass->REX[1]); // W
    //printf("REX[2] = %d\n", inst_disass->REX[2]); // R
    //printf("REX[3] = %d\n", inst_disass->REX[3]); // X
    //printf("REX[4] = %d\n", inst_disass->REX[4]); // B
    addr += decode_opcode(mem[addr], inst_disass);
    addr += decode_operande(&mem[addr], inst_disass);
    print_hex_inst(mem, inst_disass->inst_size);
    return addr;
}

int main(int argc, char *argv[]){
    int fd;
    struct stat st;
    uint8_t *mem;
    Instruction_Decoded inst_disass[10];
    int addr = 0;

    if (argc < 2) {
        fprintf(stderr, "Usage: %s <executable>\n", argv[0]);
        return 1;
    }
    fd = open(argv[1], O_RDONLY);
    fstat(fd,&st);
    mem = mmap(NULL,st.st_size,PROT_READ,MAP_PRIVATE,fd,0);
    initialize_instructions();
    inst_disass[0] = (Instruction_Decoded){0};
    inst_disass[0].op2 = -1;
    inst_disass[0].op1 = -1;
    addr += decodeInst(mem, addr, &inst_disass[0]);
    printf("next byte: %02x\n", mem[addr]);
    close(fd);
    munmap(mem, st.st_size);
    return 0;
}