gcc -Wall -g -o x64_dis x64_dis.c

python asm_to_hex.py "push 0x1234" data1
python asm_to_hex.py "push 0x12345678" data2
python asm_to_hex.py "push 0x1" data3
python asm_to_hex.py "push 0xff" data4
echo ""
for i in $(seq 1 4); do
    ./x64_dis data$i
    echo ""
done
