gcc -Wall -g -o x64_dis x64_dis.c

echo  -en "\x63\x00" > data1; echo "movsxd eax, [rax]"
echo  -en "\x67\x63\x00" > data2; echo "movsxd eax, [eax]"
echo  -en "\x48\x63\xc8" > data3; echo "movsxd rcx, eax"
echo  -en "\x63\xc0" > data4; echo "movsxd eax, eax"
echo -en "\x67\x48\x63\x80\x34\x12\x00\x00" > data5; echo "movsxd rax, [eax+0x1234]"

echo ""
for i in $(seq 1 5); do
    ./x64_dis data$i
    echo ""
done