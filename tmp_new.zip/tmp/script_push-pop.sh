if [ $# -eq 0 ]; then
    echo "Usage: $0 inst"
    exit 1
fi

gcc -Wall -g -o x64_dis x64_dis.c

python asm_to_hex.py "$1 rax" data1
python asm_to_hex.py "$1 rcx" data2
python asm_to_hex.py "$1 rdx" data3
python asm_to_hex.py "$1 rbx" data4
python asm_to_hex.py "$1 rsp" data5
python asm_to_hex.py "$1 rbp" data6
python asm_to_hex.py "$1 rsi" data7
python asm_to_hex.py "$1 rdi" data8
python asm_to_hex.py "$1 ax" data9
python asm_to_hex.py "$1 cx" data10
python asm_to_hex.py "$1 dx" data11
python asm_to_hex.py "$1 bx" data12
python asm_to_hex.py "$1 sp" data13
python asm_to_hex.py "$1 bp" data14
python asm_to_hex.py "$1 si" data15
python asm_to_hex.py "$1 di" data16
echo ""
for i in $(seq 1 16); do
    ./x64_dis data$i
    echo ""
done