import subprocess
import sys
import tempfile
import os
import pyperclip

def assemble_and_dump_hex(assembly_code, file_name):
    # Create a temporary file for the assembly code
    with tempfile.NamedTemporaryFile(delete=False, suffix='.asm') as asm_file:
        asm_file.write(b"bits 64\nsection .text\nglobal _start\n_start:\n")
        asm_file.write(assembly_code.encode('utf-8'))
        asm_file_name = asm_file.name
    
    # Create a temporary file for the binary output
    bin_file_name = asm_file_name.replace('.asm', '.bin')
    
    try:
        # Assemble the code using nasm
        subprocess.run(['nasm', '-f', 'bin', '-o', bin_file_name, asm_file_name], check=True)
        result = subprocess.run(['xxd', '-p', bin_file_name], capture_output=True, check=True, text=True)
        hex_output = ''.join([f'\\x{result.stdout[i:i+2]}' for i in range(0, len(result.stdout), 2)])
        hex_output = hex_output.replace("\n", "")
        hex_output += "61"
        print(f'{assembly_code}', end=";")
        data = hex_output.replace("\\x", " ")
        print(f'{data}')

    finally:
        os.remove(asm_file_name)
        if os.path.exists(bin_file_name):
            os.rename(bin_file_name,file_name)
            with open(file_name,"a") as f :
                f.write('a')
            

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python asm_to_hex.py \"<assembly instruction>\" <file_name>")
        sys.exit(1)

    assembly_instruction = sys.argv[1]
    file_name = sys.argv[2]
    assemble_and_dump_hex(assembly_instruction, file_name)
