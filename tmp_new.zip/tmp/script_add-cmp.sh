if [ $# -eq 0 ]; then
    echo "Usage: $0 inst"
    exit 1
fi

gcc -Wall -g -o x64_dis x64_dis.c

python asm_to_hex.py "$1 al, bl" data1
python asm_to_hex.py "$1 ax, bx" data2
python asm_to_hex.py "$1 eax, eax" data3
python asm_to_hex.py "$1 [eax], ebx" data4
python asm_to_hex.py "$1 rax, rbx" data5
python asm_to_hex.py "$1 [rax], rbx" data6
python asm_to_hex.py "$1 al, [rbx]" data7
python asm_to_hex.py "$1 rax, [rbx]" data8
python asm_to_hex.py "$1 al, 10" data9
python asm_to_hex.py "$1 rax, 0x1234" data10
python asm_to_hex.py "$1 rax, 0x12345678" data11
python asm_to_hex.py "$1 eax, [ebx+0xa]" data12
python asm_to_hex.py "$1 eax, [rbx+0xa]" data13
python asm_to_hex.py "$1 [rbx], cl" data14
python asm_to_hex.py "$1 cl, [rbx]" data15
python asm_to_hex.py "$1 ax, [rcx]" data16
python asm_to_hex.py "$1 ax, [edx]" data17
python asm_to_hex.py "$1 [rax+0x1234], rax" data18
python asm_to_hex.py "$1 [rax+0x1234], rax" data18
python asm_to_hex.py "$1 [rax+0x1234], ax" data19
python asm_to_hex.py "$1 [eax+0x1234], ax" data20
python asm_to_hex.py "$1 [eax+0x1234], eax" data21
python asm_to_hex.py "$1 [rax+0x1234], eax" data22

echo ""
for i in $(seq 1 22); do
    ./x64_dis data$i
    echo ""
done